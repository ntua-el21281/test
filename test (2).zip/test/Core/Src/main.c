/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void IntToString(int value, char* str) {
    int i = 0;
    if (value == 0) { str[0] = '0'; str[1] = '\0'; return; }
    char temp[10];
    int j = 0;
    while (value > 0) { temp[j++] = (value % 10) + '0'; value /= 10; }
    while (j > 0) { str[i++] = temp[--j]; }
    str[i] = '\0';
}

void LCD_Pulse() {
    LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_3);
    LL_mDelay(1);
    LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_3);
    LL_mDelay(1);
}

void LCD_Send4Bit(uint8_t val) {
    LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_4 | LL_GPIO_PIN_5 | LL_GPIO_PIN_6 | LL_GPIO_PIN_7);
    if (val & 0x01) LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_4);
    if (val & 0x02) LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_5);
    if (val & 0x04) LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_6);
    if (val & 0x08) LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_7);
    LCD_Pulse();
}

void LCD_Cmd(uint8_t cmd) {
    LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_2);
    LCD_Send4Bit(cmd >> 4);
    LCD_Send4Bit(cmd);
    LL_mDelay(2);
}

void LCD_Data(uint8_t data) {
    LL_GPIO_SetOutputPin(GPIOA, LL_GPIO_PIN_2);
    LCD_Send4Bit(data >> 4);
    LCD_Send4Bit(data);
    LL_mDelay(1);
}

void LCD_Clear() {
    LCD_Cmd(0x01); // Εντολή καθαρισμού
    LL_mDelay(2);
}

void LCD_Home() {
    LCD_Cmd(0x80); // Μετακίνηση στην αρχή (Line 1, Col 1)
}

void LCD_NewLine() {
    LCD_Cmd(0xC0); // Μετακίνηση στη 2η γραμμή
}

void LCD_Init() {
    LL_mDelay(50);
    LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_2);
    LCD_Send4Bit(0x03); LL_mDelay(5);
    LCD_Send4Bit(0x03); LL_mDelay(1);
    LCD_Send4Bit(0x03); LL_mDelay(1);
    LCD_Send4Bit(0x02);
    LL_mDelay(1);
    LCD_Cmd(0x28); LCD_Cmd(0x0C); LCD_Cmd(0x06); LCD_Cmd(0x01);
    LL_mDelay(5);
}

void LCD_String(char *str) { while(*str) LCD_Data(*str++); }


// --- ΤΡΟΠΟΠΟΙΗΜΕΝΗ ΣΥΝΑΡΤΗΣΗ ADC ---
// Πλέον δέχεται το Channel ως όρισμα για να επιλέγουμε μεταξύ POT1 και POT2
uint16_t Read_ADC_Channel(uint32_t Channel) {
    // Επιλογή καναλιού (Channel 6 για POT1, Channel 14 για POT2)
    LL_ADC_REG_SetSequencerRanks(ADC1, LL_ADC_REG_RANK_1, Channel);

    // Μικρή καθυστέρηση για σταθεροποίηση
    LL_mDelay(1);

    // Έναρξη μετατροπής
    LL_ADC_REG_StartConversion(ADC1);

    // Αναμονή μέχρι να τελειώσει
    while (!LL_ADC_IsActiveFlag_EOC(ADC1));

    // Επιστροφή τιμής
    return LL_ADC_REG_ReadConversionData12(ADC1);
}

char Keypad_Scan(void) {
    char key = 0;
    // Row 0
    LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_0);
    LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_1 | LL_GPIO_PIN_2 | LL_GPIO_PIN_3);
    LL_mDelay(1);
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_4)) key = '*';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_5)) key = '0';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_6)) key = '#';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_7)) key = 'D';
    if(key) return key;

    // Row 1
    LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_1);
    LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_0 | LL_GPIO_PIN_2 | LL_GPIO_PIN_3);
    LL_mDelay(1);
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_4)) key = '7';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_5)) key = '8';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_6)) key = '9';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_7)) key = 'C';
    if(key) return key;

    // Row 2
    LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_2);
    LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_0 | LL_GPIO_PIN_1 | LL_GPIO_PIN_3);
    LL_mDelay(1);
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_4)) key = '4';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_5)) key = '5';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_6)) key = '6';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_7)) key = 'B';
    if(key) return key;

    // Row 3
    LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_3);
    LL_GPIO_SetOutputPin(GPIOB, LL_GPIO_PIN_0 | LL_GPIO_PIN_1 | LL_GPIO_PIN_2);
    LL_mDelay(1);
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_4)) key = '1';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_5)) key = '2';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_6)) key = '3';
    if(!LL_GPIO_IsInputPinSet(GPIOB, LL_GPIO_PIN_7)) key = 'A';
    return key;

}

// --- UART4 (Προς PC/Putty) ---
void UART_SendChar(char ch) {
    while (!LL_USART_IsActiveFlag_TXE(UART4)) {}
    LL_USART_TransmitData8(UART4, ch);
}

void UART_SendString(char *str) {
    while (*str) {
        UART_SendChar(*str++);
    }
}

// --- UART5 (Προς ESP8266) ---
void UART5_SendChar(char ch) {
    while (!LL_USART_IsActiveFlag_TXE(UART5)) {}
    LL_USART_TransmitData8(UART5, ch);
}

void UART5_SendString(char *str) {
    while (*str) {
        UART5_SendChar(*str++);
    }
}

int ESP_WaitResponse(char *target, uint32_t timeout) {
    char buffer[64]; // Λίγο μεγαλύτερος buffer
    int idx = 0;

    // Καθαρισμός buffer
    memset(buffer, 0, 64);

    // Loop όσο υπάρχει χρόνος (timeout είναι σε χιλιοστά του δευτερολέπτου)
    while (timeout > 0) {
        // Ελέγχουμε αν υπάρχει δεδομένο στη UART5 (ESP)
        if (LL_USART_IsActiveFlag_RXNE(UART5)) {
            char c = LL_USART_ReceiveData8(UART5);

            // ECHO: Στείλε τον χαρακτήρα στο Putty (UART4) για να βλέπεις τι γίνεται
            UART_SendChar(c);

            // Αποθήκευση στον buffer
            if (idx < 63) {
                buffer[idx++] = c;
                buffer[idx] = '\0'; // Τερματισμός string
            } else {
                // Αν γεμίσει, μετακινούμε τα δεδομένα προς τα πίσω (Shift)
                for(int i=0; i<62; i++) buffer[i] = buffer[i+1];
                buffer[62] = c;
                idx = 63;
            }

            // Έλεγχος αν βρέθηκε η λέξη στόχος (π.χ. "OK")
            if (strstr(buffer, target) != NULL) {
                return 1; // Βρέθηκε!
            }

            // Επιπλέον έλεγχος για το '>' (αν ζητάμε να στείλουμε δεδομένα)
            if (c == '>' && target[0] == '>') return 1;

        } else {
            // Αν δεν έχει έρθει χαρακτήρας, περιμένουμε 1ms και μειώνουμε τον χρόνο
            LL_mDelay(1);
            timeout--;
        }
    }
    return 0; // Τέλειωσε ο χρόνος (Timeout)
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);

  /* System interrupt init*/
  NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /** Disable the internal Pull-Up in Dead Battery pins of UCPD peripheral
  */
  LL_PWR_DisableUCPDDeadBattery();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  /* USER CODE BEGIN 2 */
  LL_USART_Enable(UART4);
    LL_USART_Enable(UART5);
    LL_mDelay(100);

    LCD_Init(); LCD_Clear();
    UART_SendString("\r\n=== STM32 START ===\r\n");

    // 1. RESTART (Όπως στον AVR)
    LCD_String("ESP Restart...");
    UART5_SendString("ESP:restart\n"); // Προσοχή: Μόνο \n στο τέλος (όχι \r\n)
    LL_mDelay(3000);

    // 2. CONNECT (ESP:connect)
    LCD_Clear(); LCD_String("Connecting...");
    int connected = 0;

    // Προσπαθούμε μέχρι να συνδεθεί (Loop)
    while(connected == 0) {
        UART5_SendString("ESP:connect\n");

        // Περιμένουμε την απάντηση "Success"
        if(ESP_WaitResponse("Success", 3000)) {
            connected = 1;
            LCD_Clear(); LCD_String("Connect OK!");
            UART_SendString("WiFi Connected!\r\n");
        } else {
            LCD_Clear(); LCD_String("Connect Fail");
            UART_SendString("Retrying connection...\r\n");
            LL_mDelay(2000);
        }
    }

    // 3. SET URL (ESP:url)
    LCD_Clear(); LCD_String("Set URL...");

    // ΠΡΟΣΟΧΗ: Βάλε τη δική σου IP και Port (5000) εδώ!
    // Η σύνταξη πρέπει να είναι ακριβώς: ESP:url:"http://IP:PORT/data"\n
    char url_cmd[100];
    sprintf(url_cmd, "ESP:url:\"http://192.168.1.X:5000/data\"\n");
    UART5_SendString(url_cmd);

    if(ESP_WaitResponse("Success", 3000)) {
        LCD_Clear(); LCD_String("System Ready!");
    } else {
        LCD_Clear(); LCD_String("URL Fail"); // Συνήθως περνάει ακόμα κι αν δεν βρει τον server
    }

    LL_mDelay(1000);

    // Ενεργοποίηση περιφερειακών
    if (!LL_ADC_IsEnabled(ADC1)) { LL_ADC_Enable(ADC1); LL_mDelay(1); }
    LL_TIM_EnableCounter(TIM2); LL_TIM_CC_EnableChannel(TIM2, LL_TIM_CHANNEL_CH1);

    char strBuf[10];
    char payload[100]; // Buffer για το μήνυμα
    char pressedKey;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  // --- Σάρωση 1ης Γραμμής (ROW0 - PB0) ---
	  // 1. Σάρωση
	      pressedKey = Keypad_Scan();

	      // 2. Έλεγχος αν βρέθηκε κουμπί
	      if (pressedKey == '#')
	            {
	                uint16_t adc_val = Read_ADC_Channel(LL_ADC_CHANNEL_6);
	                LL_TIM_OC_SetCompareCH1(TIM2, adc_val);

	                // Εμφάνιση LCD
	                LCD_Clear(); LCD_Home(); LCD_String("POT1: ");
	                IntToString(adc_val, strBuf); LCD_String(strBuf);

	                // --- ΑΠΟΣΤΟΛΗ ΜΕ ΤΟΝ ΤΡΟΠΟ ΤΟΥ AVR ---

	                // 1. Ετοιμασία Payload (JSON μορφή)
	                // Φτιάχνουμε το string: ESP:payload:[{"name":"pot1","value":"1234"}]\n
	                sprintf(payload, "ESP:payload:[{\"name\":\"pot1\",\"value\":\"%d\"}]\n", adc_val);
	                UART5_SendString(payload);

	                // Debug στο Putty για να βλέπεις τι στέλνεις
	                UART_SendString("Sent Payload: "); UART_SendString(payload);

	                // Μικρή καθυστέρηση όπως στον AVR
	                LL_mDelay(100);

	                // 2. Εντολή Transmit
	                UART5_SendString("ESP:transmit\n");

	                // Έλεγχος αν πέτυχε (προαιρετικά)
	                if(ESP_WaitResponse("Success", 2000)) {
	                    LCD_NewLine(); LCD_String("Sent OK");
	                } else {
	                    LCD_NewLine(); LCD_String("Sent Fail");
	                }

	                LL_mDelay(1000);
	            }
	      else if (pressedKey == 'D')
	            {
	                // 1. Διάβασμα POT2 (Channel 14)
	                uint16_t adc_val = Read_ADC_Channel(LL_ADC_CHANNEL_14);

	                // Ενημέρωση PWM (για οπτική επιβεβαίωση στο LED)
	                LL_TIM_OC_SetCompareCH1(TIM2, adc_val);

	                // Εμφάνιση στην LCD
	                LCD_Clear(); LCD_Home(); LCD_String("POT2: ");
	                IntToString(adc_val, strBuf); LCD_String(strBuf);

	                // --- ΑΠΟΣΤΟΛΗ ΜΕ ΤΟΝ ΤΡΟΠΟ ΤΟΥ AVR ---

	                // 1. Ετοιμασία Payload (JSON μορφή για POT2)
	                // Φτιάχνουμε το string: ESP:payload:[{"name":"pot2","value":"1234"}]\n
	                sprintf(payload, "ESP:payload:[{\"name\":\"pot2\",\"value\":\"%d\"}]\n", adc_val);
	                UART5_SendString(payload);

	                // Debug στο Putty (για να βλέπεις τι φεύγει)
	                UART_SendString("Sent Payload POT2: "); UART_SendString(payload);

	                // Μικρή καθυστέρηση (όπως στον AVR)
	                LL_mDelay(100);

	                // 2. Εντολή Transmit
	                UART5_SendString("ESP:transmit\n");

	                // Έλεγχος αν πέτυχε (Success)
	                if(ESP_WaitResponse("Success", 2000)) {
	                    LCD_NewLine(); LCD_String("Sent OK");
	                } else {
	                    LCD_NewLine(); LCD_String("Sent Fail");
	                }

	                LL_mDelay(1000); // Καθυστέρηση για να προλάβεις να δεις το μήνυμα
	                LCD_Clear(); LCD_Home();
	            }


	            // Debounce: Περίμενε να αφήσεις το κουμπί

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_4);
  while(LL_FLASH_GetLatency() != LL_FLASH_LATENCY_4)
  {
  }
  LL_PWR_EnableRange1BoostMode();
  LL_RCC_HSI_Enable();
   /* Wait till HSI is ready */
  while(LL_RCC_HSI_IsReady() != 1)
  {
  }

  LL_RCC_HSI_SetCalibTrimming(64);
  LL_RCC_PLL_ConfigDomain_SYS(LL_RCC_PLLSOURCE_HSI, LL_RCC_PLLM_DIV_4, 85, LL_RCC_PLLR_DIV_2);
  LL_RCC_PLL_EnableDomain_SYS();
  LL_RCC_PLL_Enable();
   /* Wait till PLL is ready */
  while(LL_RCC_PLL_IsReady() != 1)
  {
  }

  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_PLL);
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_2);
   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_PLL)
  {
  }

  /* Insure 1us transition state at intermediate medium speed clock*/
  for (__IO uint32_t i = (170 >> 1); i !=0; i--);

  /* Set AHB prescaler*/
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_1);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_1);

  LL_Init1msTick(170000000);

  LL_SetSystemCoreClock(170000000);
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  LL_ADC_InitTypeDef ADC_InitStruct = {0};
  LL_ADC_REG_InitTypeDef ADC_REG_InitStruct = {0};
  LL_ADC_CommonInitTypeDef ADC_CommonInitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  LL_RCC_SetADCClockSource(LL_RCC_ADC12_CLKSOURCE_SYSCLK);

  /* Peripheral clock enable */
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_ADC12);

  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);
  /**ADC1 GPIO Configuration
  PC0   ------> ADC1_IN6
  PB11   ------> ADC1_IN14
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_0;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LL_GPIO_PIN_11;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  ADC_InitStruct.Resolution = LL_ADC_RESOLUTION_12B;
  ADC_InitStruct.DataAlignment = LL_ADC_DATA_ALIGN_RIGHT;
  ADC_InitStruct.LowPowerMode = LL_ADC_LP_MODE_NONE;
  LL_ADC_Init(ADC1, &ADC_InitStruct);
  ADC_REG_InitStruct.TriggerSource = LL_ADC_REG_TRIG_SOFTWARE;
  ADC_REG_InitStruct.SequencerLength = LL_ADC_REG_SEQ_SCAN_DISABLE;
  ADC_REG_InitStruct.SequencerDiscont = LL_ADC_REG_SEQ_DISCONT_DISABLE;
  ADC_REG_InitStruct.ContinuousMode = LL_ADC_REG_CONV_SINGLE;
  ADC_REG_InitStruct.DMATransfer = LL_ADC_REG_DMA_TRANSFER_NONE;
  ADC_REG_InitStruct.Overrun = LL_ADC_REG_OVR_DATA_PRESERVED;
  LL_ADC_REG_Init(ADC1, &ADC_REG_InitStruct);
  LL_ADC_SetGainCompensation(ADC1, 0);
  LL_ADC_SetOverSamplingScope(ADC1, LL_ADC_OVS_DISABLE);
  ADC_CommonInitStruct.CommonClock = LL_ADC_CLOCK_SYNC_PCLK_DIV4;
  ADC_CommonInitStruct.Multimode = LL_ADC_MULTI_INDEPENDENT;
  LL_ADC_CommonInit(__LL_ADC_COMMON_INSTANCE(ADC1), &ADC_CommonInitStruct);

  /* Disable ADC deep power down (enabled by default after reset state) */
  LL_ADC_DisableDeepPowerDown(ADC1);
  /* Enable ADC internal voltage regulator */
  LL_ADC_EnableInternalRegulator(ADC1);
  /* Delay for ADC internal voltage regulator stabilization. */
  /* Compute number of CPU cycles to wait for, from delay in us. */
  /* Note: Variable divided by 2 to compensate partially */
  /* CPU processing cycles (depends on compilation optimization). */
  /* Note: If system core clock frequency is below 200kHz, wait time */
  /* is only a few CPU processing cycles. */
  uint32_t wait_loop_index;
  wait_loop_index = ((LL_ADC_DELAY_INTERNAL_REGUL_STAB_US * (SystemCoreClock / (100000 * 2))) / 10);
  while(wait_loop_index != 0)
  {
    wait_loop_index--;
  }

  /** Configure Regular Channel
  */
  LL_ADC_REG_SetSequencerRanks(ADC1, LL_ADC_REG_RANK_1, LL_ADC_CHANNEL_6);
  LL_ADC_SetChannelSamplingTime(ADC1, LL_ADC_CHANNEL_6, LL_ADC_SAMPLINGTIME_2CYCLES_5);
  LL_ADC_SetChannelSingleDiff(ADC1, LL_ADC_CHANNEL_6, LL_ADC_SINGLE_ENDED);
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};
  LL_TIM_OC_InitTypeDef TIM_OC_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  TIM_InitStruct.Prescaler = 0;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 4095;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM2, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM2);
  LL_TIM_OC_EnablePreload(TIM2, LL_TIM_CHANNEL_CH1);
  TIM_OC_InitStruct.OCMode = LL_TIM_OCMODE_PWM1;
  TIM_OC_InitStruct.OCState = LL_TIM_OCSTATE_DISABLE;
  TIM_OC_InitStruct.OCNState = LL_TIM_OCSTATE_DISABLE;
  TIM_OC_InitStruct.CompareValue = 0;
  TIM_OC_InitStruct.OCPolarity = LL_TIM_OCPOLARITY_HIGH;
  LL_TIM_OC_Init(TIM2, LL_TIM_CHANNEL_CH1, &TIM_OC_InitStruct);
  LL_TIM_OC_DisableFast(TIM2, LL_TIM_CHANNEL_CH1);
  LL_TIM_SetTriggerOutput(TIM2, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM2);
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
  /**TIM2 GPIO Configuration
  PA0   ------> TIM2_CH1
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_0;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_1;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  LL_USART_InitTypeDef USART_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  LL_RCC_SetUARTClockSource(LL_RCC_UART4_CLKSOURCE_PCLK1);

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_UART4);

  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  /**UART4 GPIO Configuration
  PC10   ------> UART4_TX
  PC11   ------> UART4_RX
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_10;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_5;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LL_GPIO_PIN_11;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_5;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  USART_InitStruct.PrescalerValue = LL_USART_PRESCALER_DIV1;
  USART_InitStruct.BaudRate = 9600;
  USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
  USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
  USART_InitStruct.Parity = LL_USART_PARITY_NONE;
  USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
  USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
  USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
  LL_USART_Init(UART4, &USART_InitStruct);
  LL_USART_DisableFIFO(UART4);
  LL_USART_SetTXFIFOThreshold(UART4, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_SetRXFIFOThreshold(UART4, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_ConfigAsyncMode(UART4);

  /* USER CODE BEGIN WKUPType UART4 */

  /* USER CODE END WKUPType UART4 */

  LL_USART_Enable(UART4);

  /* Polling UART4 initialisation */
  while((!(LL_USART_IsActiveFlag_TEACK(UART4))) || (!(LL_USART_IsActiveFlag_REACK(UART4))))
  {
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  LL_USART_InitTypeDef USART_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  LL_RCC_SetUARTClockSource(LL_RCC_UART5_CLKSOURCE_PCLK1);

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_UART5);

  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOD);
  /**UART5 GPIO Configuration
  PC12   ------> UART5_TX
  PD2   ------> UART5_RX
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_12;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_5;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LL_GPIO_PIN_2;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  GPIO_InitStruct.Alternate = LL_GPIO_AF_5;
  LL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  USART_InitStruct.PrescalerValue = LL_USART_PRESCALER_DIV1;
  USART_InitStruct.BaudRate = 9600;
  USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
  USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
  USART_InitStruct.Parity = LL_USART_PARITY_NONE;
  USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
  USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
  USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
  LL_USART_Init(UART5, &USART_InitStruct);
  LL_USART_DisableFIFO(UART5);
  LL_USART_SetTXFIFOThreshold(UART5, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_SetRXFIFOThreshold(UART5, LL_USART_FIFOTHRESHOLD_1_8);
  LL_USART_ConfigAsyncMode(UART5);

  /* USER CODE BEGIN WKUPType UART5 */

  /* USER CODE END WKUPType UART5 */

  LL_USART_Enable(UART5);

  /* Polling UART5 initialisation */
  while((!(LL_USART_IsActiveFlag_TEACK(UART5))) || (!(LL_USART_IsActiveFlag_REACK(UART5))))
  {
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOB);
  LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOD);

  /**/
  LL_GPIO_ResetOutputPin(LCD_RS_GPIO_Port, LCD_RS_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LCD_EN_GPIO_Port, LCD_EN_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LCD_D4_GPIO_Port, LCD_D4_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LCD_D5_GPIO_Port, LCD_D5_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LCD_D6_GPIO_Port, LCD_D6_Pin);

  /**/
  LL_GPIO_ResetOutputPin(LCD_D7_GPIO_Port, LCD_D7_Pin);

  /**/
  LL_GPIO_ResetOutputPin(ROW0_GPIO_Port, ROW0_Pin);

  /**/
  LL_GPIO_ResetOutputPin(ROW1_GPIO_Port, ROW1_Pin);

  /**/
  LL_GPIO_ResetOutputPin(ROW2_GPIO_Port, ROW2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(ROW3_GPIO_Port, ROW3_Pin);

  /**/
  GPIO_InitStruct.Pin = LCD_RS_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_RS_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LCD_EN_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_EN_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LCD_D4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_D4_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LCD_D5_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_D5_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LCD_D6_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_D6_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LCD_D7_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(LCD_D7_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = ROW0_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(ROW0_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = ROW1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(ROW1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = ROW2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(ROW2_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = ROW3_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(ROW3_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = COL0_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(COL0_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = COL1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(COL1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = COL2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(COL2_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = COL3_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(COL3_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
